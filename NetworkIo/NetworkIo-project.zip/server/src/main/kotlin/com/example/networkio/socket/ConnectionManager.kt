    package com.example.networkio.socket

    import com.example.networkio.model.Message
    import com.example.networkio.model.ServerEvent
    import kotlinx.coroutines.sync.Mutex
    import kotlinx.coroutines.sync.withLock
    import kotlinx.serialization.json.Json

    class ConnectionManager(
        private val json:Json =Json{
            ignoreUnknownKeys=true
            encodeDefaults=true
            allowTrailingComma=true
        }
    ){
        private val sessions=mutableMapOf<String,ClientSession>()
        private val lock= Mutex()

        suspend fun add(session: ClientSession){
            lock.withLock { sessions[session.id]=session }
            broadcastEvent(ServerEvent.Joined(session.id))
        }

        suspend fun remove(id:String) {
            lock.withLock { sessions.remove(id) }
            broadcastEvent(ServerEvent.Left(id))
        }

        suspend fun broadcastEvent(event: ServerEvent) {
            val snapshot=lock.withLock { sessions.values.toList() }
            snapshot.forEach() { it.sendEvent(event) }
        }

        suspend fun broadcastMessage(message: Message){
            val snapshot=lock.withLock { sessions.values.toList() }
            snapshot.forEach { it.sendSerialized(message) }
        }
    }