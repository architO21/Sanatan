package com.example.networkio.model

import kotlinx.serialization.Serializable

@Serializable
sealed class ServerEvent{
    @Serializable
    data class Joined(val id:String):ServerEvent()
    @Serializable
    data class Left(val id:String):ServerEvent()
    @Serializable
    data class Broadcast(val message:Message):ServerEvent()
    @Serializable
    data class MessageReceived(val messageId: String, val timestamp: Long, val status: String = "delivered"):ServerEvent()
}