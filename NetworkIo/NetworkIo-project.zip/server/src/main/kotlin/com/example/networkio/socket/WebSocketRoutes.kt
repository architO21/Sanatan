    package com.example.networkio.socket

    import com.example.networkio.model.Message
    import io.ktor.server.routing.*
    import io.ktor.server.websocket.*
    import io.ktor.websocket.*
    import kotlinx.coroutines.channels.consumeEach
    import kotlinx.serialization.json.Json
    import java.util.UUID

    fun Route.socketRoutes(manager: ConnectionManager) {
        webSocket("/ws") {
            val json = Json {
                ignoreUnknownKeys = true
                encodeDefaults = true
            }
            // Get client ID from query params or generate new one
            val clientId = call.request.queryParameters["id"] ?: UUID.randomUUID().toString()
            val client = ClientSession(clientId, this, json)
            manager.add(client)
            try {
                // Listen for incoming messages
                incoming.consumeEach { frame ->
                    if (frame is Frame.Text) {
                        val message = json.decodeFromString<Message>(frame.readText())
                        print("Archit" to message)

                        // Send acknowledgment to sender
                        client.sendEvent(
                            com.example.networkio.model.ServerEvent.MessageReceived(
                                messageId = message.from,
                                timestamp = System.currentTimeMillis(),
                                status = "received"
                            )
                        )

                        // Broadcast message with sender ID and timestamp
                        manager.broadcastMessage(
                            message.copy(
                                from = message.from.ifBlank { clientId },
                                timestamp = System.currentTimeMillis()
                            )
                        )
                    }
                }
            } finally {
                manager.remove(clientId)
            }
        }
    }